document.addEventListener('DOMContentLoaded', function() {

    // Use buttons to toggle between views
    document.querySelector('#visited').addEventListener('click', () => load_mailbox('inbox'));

  });